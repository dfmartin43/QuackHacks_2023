# qpong-livestream
For 12 Days of Qiskit live streaming: "Let's build QPong from scratch!". Click the image below to watch the recording on Qiskit Youtube.

## Part 1

[![Let’s build QPong from scratch! Part 1](https://img.youtube.com/vi/C-tCZAC1Qq8/0.jpg)](https://www.youtube.com/watch?v=C-tCZAC1Qq8&list=PLOFEBzvs-VvodTkP_rfrs3RWdeWE9aNRD&index=2)

## Part 2

[![Let’s build QPong from scratch! Part 2](https://img.youtube.com/vi/PYthycN_Tq8/0.jpg)](https://www.youtube.com/watch?v=PYthycN_Tq8&list=PLOFEBzvs-VvodTkP_rfrs3RWdeWE9aNRD&index=4)
